#!/bin/sh
# loops a cmd, by jimmy

/usr/local/php/bin/php /YOKA/SBIN/loop.php "$1" "$2" "$3"
