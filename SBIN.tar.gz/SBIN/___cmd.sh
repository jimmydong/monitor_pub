#!/bin/sh
echo 'remove 0 size file in current folder...';
#find . -maxdepth 1 -type f -size 0 -exec rm -f {} \; echo 'done'

