#!/bin/sh

##
# cp every JD.config file to the right location
# by jimmy 2009.05.19

echo "You should install apt and tsocks first, use the rpm pakage."

#cp JD.authorized_keys /root/.ssh/authorized_keys
cp JD.bash_profile /root/.bash_profile
cp JD.colorls.sh /etc/profile.d/colorls.sh
chmod +x /etc/profile.d/colorls.sh
cp JD.jimmy.sh /etc/profile.d/jimmy.sh
chmod +x /etc/profile.d/jimmy.sh
mkdir /etc/snmp
cp JD.snmpd.conf /etc/snmp/snmpd.conf
cp JD.tsocks.conf /etc/tsocks.conf
cp JD.sources.list /etc/apt/sources.list
rm /etc/apt/sources.list.d/* -f
cat /etc/tsocks.conf
cp JD.RHEL5.remote.repo /etc/yum.repos.d/jimmy.repo

echo "Remember:"
echo "1, edit /etc/apt/apt.conf, uncheck GPG-Check"
echo "2, edit /etc/apt/sources.list, correct redhat verion"
echo ""
